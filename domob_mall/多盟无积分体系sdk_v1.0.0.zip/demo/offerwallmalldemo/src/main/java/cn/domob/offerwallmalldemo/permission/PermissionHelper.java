package cn.domob.offerwallmalldemo.permission;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.util.Pair;

/**
 * Android 6.0 权限申请助手
 * Created by 黄洞洞 on 16-08-02.
 */
public class PermissionHelper {

	private static final String TAG = "PermissionHelper";

	/**
	 * 这里的int数值不能太大，否则不会弹出请求权限提示，测试的时候,改到1000就不会弹出请求了
	 */
	private final static int READ_PHONE_STATE_CODE = 131;
	private final static int WRITE_EXTERNAL_STORAGE_CODE = 132;

	private final String hasrefuseforever="hasRefuseForever";
	/**
	 * 多盟 Android SDK 所需要向用户申请的权限列表
	 */
	private PermissionModel[] mPermissionModels = new PermissionModel[] {
			new PermissionModel("电话", Manifest.permission.READ_PHONE_STATE, "开启本权限才能顺利做任务哦！返回点击'允许'", READ_PHONE_STATE_CODE),
			new PermissionModel("存储空间", Manifest.permission.WRITE_EXTERNAL_STORAGE, "开启本权限才能顺利做任务哦！返回点击'允许'",
					WRITE_EXTERNAL_STORAGE_CODE)
	};

	private Activity mActivity;
	private OnGainPermissionListener onGainPermissionListener;
	public PermissionHelper(Activity activity) {
		mActivity = activity;
	}
	public void setOnApplyPermissionListener(OnGainPermissionListener onGainPermissionListener) {
		this.onGainPermissionListener = onGainPermissionListener;
	}
	/**
	 * 在Android 6.0+上运行时申请权限
	 */
	public void applyPermissions() {
		try {
			if(isAllRequestedPermissionGranted()){
				//更改存储的状态
				SPUtils.put(mActivity,hasrefuseforever,false);
				if (onGainPermissionListener != null) {
					onGainPermissionListener.onAllPermissionGained();
					return;
				}
			}

			//判断用户是否已经勾选了不再显示
			boolean aBoolean = (boolean) SPUtils.get(mActivity,hasrefuseforever,false);
			if(aBoolean){
				if(onGainPermissionListener!=null){
					onGainPermissionListener.onGainedFail();
				}
			}

			for (final PermissionModel model : mPermissionModels) {
				if (PackageManager.PERMISSION_GRANTED != ContextCompat.checkSelfPermission(mActivity, model.permission)) {
					ActivityCompat.requestPermissions(mActivity, new String[] { model.permission }, model.requestCode);
					return;
				}
			}

		} catch (Throwable e) {
			Log.e(TAG, "", e);
		}
	}
	/**
	 * 对应Activity的 {@code onRequestPermissionsResult(...)} 方法
	 *
	 */
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		switch (requestCode) {
		case READ_PHONE_STATE_CODE:
		case WRITE_EXTERNAL_STORAGE_CODE:
			// 如果用户不允许，我们视情况发起二次请求或者引导用户到应用页面手动打开
			if (PackageManager.PERMISSION_GRANTED != grantResults[0]) {
				//用户拒绝了某个权限
				if (ActivityCompat.shouldShowRequestPermissionRationale(mActivity, permissions[0])) {
					Pair<String,String> permission_msg;
					permission_msg=getPermissionMsg(permissions[0]);
					if(onGainPermissionListener!=null){
						onGainPermissionListener.onRefuse(permission_msg);
					}
				}
				//用户勾选了不再提示，永远拒绝了权限
				else {
					//用户是否勾选不再显示
					SPUtils.put(mActivity,hasrefuseforever,true);
					if(onGainPermissionListener!=null){
						onGainPermissionListener.onRefuseForever();
					}
				}
				return;
			}
			// 到这里就表示用户允许了本次请求，我们继续检查是否还有待申请的权限没有申请
			if (isAllRequestedPermissionGranted()) {
				//用户是否勾选不再显示
				SPUtils.put(mActivity,hasrefuseforever,false);
				if (onGainPermissionListener != null) {
					onGainPermissionListener.onAllPermissionGained();
				}
			} else {
				applyPermissions();
			}
			break;
		}
	}


	/**
	 * 判断是否所有的权限都被授权了
	 *
	 * @return
	 */
	private boolean isAllRequestedPermissionGranted() {
		for (PermissionModel model : mPermissionModels) {
			if (PackageManager.PERMISSION_GRANTED != ContextCompat.checkSelfPermission(mActivity, model.permission)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 获取某个权限的名称和描述
	 * @param permission
	 * @return
     */
	private Pair<String,String> getPermissionMsg(String permission) {
		Pair<String,String> pair=null;
		if (mPermissionModels != null) {
			for (PermissionModel model : mPermissionModels) {
				if (model != null && model.permission != null && model.permission.equals(permission)) {
					pair=new Pair<String,String>(model.name,model.explain);
				}
			}
		}
		return pair;
	}

	private static class PermissionModel {

		/**
		 * 权限名称
		 */
		public String name;

		/**
		 * 请求的权限
		 */
		public String permission;

		/**
		 * 解析为什么请求这个权限
		 */
		public String explain;

		/**
		 * 请求代码
		 */
		public int requestCode;

		public PermissionModel(String name, String permission, String explain, int requestCode) {
			this.name = name;
			this.permission = permission;
			this.explain = explain;
			this.requestCode = requestCode;
		}
	}

	
}
