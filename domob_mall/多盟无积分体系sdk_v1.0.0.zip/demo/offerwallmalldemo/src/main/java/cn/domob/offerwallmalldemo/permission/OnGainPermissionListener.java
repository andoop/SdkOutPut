package cn.domob.offerwallmalldemo.permission;

import android.util.Pair;

/**
 * Created by 黄洞洞 on 2016/8/2.
 *
 */
public interface OnGainPermissionListener {
    /**
     * 多盟sdk申请的权限全部被获取
     */
    void onAllPermissionGained();

    /**
     * 当用户拒绝某个权限时
     * @param permission_msg
     */
    void onRefuse(Pair<String, String> permission_msg);

    /**
     * 当用户勾选不再显示，并拒绝授权
     */
    void onRefuseForever();
    /**
     * 最终，申请的权限没有被全部获取
     */
    void onGainedFail();
}
