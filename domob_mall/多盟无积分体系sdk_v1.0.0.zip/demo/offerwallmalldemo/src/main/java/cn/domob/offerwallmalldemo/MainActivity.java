package cn.domob.offerwallmalldemo;

import android.app.AlertDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.util.Pair;
import android.view.View;
import android.webkit.WebView;
import android.widget.Toast;

import cn.domob.offerwallmalldemo.permission.OnGainPermissionListener;
import cn.domob.offerwallmalldemo.permission.PermissionHelper;
import cn.dow.android.DOW;
import cn.mall.DmMall;
import cn.mall.DmMallConfig;
import cn.mall.listener.DmMallEnterListener;
import cn.mall.listener.DmMallListener;

public class MainActivity extends AppCompatActivity {
    private String TAG=MainActivity.class.getSimpleName();
    private String userHeadImgUrl="http://p0.ifengimg.com/pmop/2017/0108/5F3835104557B80CA98191E6E5F83741D612A364_size52_w600_h400.jpeg";
    //权限申请帮助类
    private PermissionHelper mPermissionHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mPermissionHelper=new PermissionHelper(this);
        //申请权限
        mPermissionHelper.setOnApplyPermissionListener(new OnGainPermissionListener() {
            @Override
            public void onAllPermissionGained() {
                Toast.makeText(MainActivity.this, "已获得所有权限", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onRefuse(Pair<String, String> permission_msg) {
                Toast.makeText(MainActivity.this,"您拒绝了'"+permission_msg.first+"'权限"+" :: "+permission_msg.second, Toast.LENGTH_SHORT).show();

            }
            //用户禁止权限，并且勾选不再提示
            @Override
            public void onRefuseForever() {
                //在这里可以提示用户跳转到系统权限设置页面，
                Toast.makeText(MainActivity.this, "请前往设置中开启本应用所需权限", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onGainedFail() {
                Toast.makeText(MainActivity.this, "获取权限失败", Toast.LENGTH_SHORT).show();
            }
        });

        //初始化
        DOW.getInstance(MainActivity.this).init();
        //设置用户id，不是publishid。此id为开发者用户体系中的用户id，没有这可以不进行设置。
        DOW.getInstance(MainActivity.this).setUserId("123");

    }

    /**
     * 检查权限获取情况，6.0及6.0以上设备
     * @param view
     */
    public void check(View view){
        mPermissionHelper.applyPermissions();
    }
    /**
     * 进入积分商城
     * @param view
     */
    public void enterMall(View view){
        Log.e("----->" + "MainActivity", "enterMall:");
        //积分商城的配置
        DmMallConfig config=new DmMallConfig.Buider()
                .navColor("#fc5335")//设置商城状态栏颜色，可选
                .titleColor("#ffffff")//设置商城标题颜色，可选
                .backImgResId(R.drawable.ic_back)//设置返回按钮图标，可选
                .userHeadImgUrl(userHeadImgUrl)//设置用户头像对应的url，如果没有则可以不设置，可选
                .dmMallListener(new DmMallListener() {//配置商城事件响应的回调，可选
                    @Override
                    public void onShareClick(WebView webView, String shareUrl, String shareThumbnail, String shareTitle, String shareSubtitle) {
                        //当分享按钮被点击时，会调用此处代码。在这里处理分享的业务逻辑。
                        new AlertDialog.Builder(webView.getContext())
                                .setTitle("分享信息1")
                                .setItems(new String[] {"标题1："+shareTitle,"副标题："+shareSubtitle,"缩略图地址："+shareThumbnail,"链接："+shareUrl}, null)
                                .setNegativeButton("确定", null)
                                .show();
                    }

                    @Override
                    public void onCopyCode(WebView webView, String code) {
                        //复制券码的时候，会调用此处代码。
                        new AlertDialog.Builder(webView.getContext())
                                .setTitle("复制券码1")
                                .setMessage("已复制，券码为："+code)
                                .setPositiveButton("是", null)
                                .setNegativeButton("否", null)
                                .show();
                    }

                    @Override
                    public void onLocalRefresh(WebView mWebView, String credits) {
                        //String credits为积分商城返回的最新积分，不保证准确。
                        //触发更新本地积分，这里建议向自己服务器请求积分值，比较准确。
                        Toast.makeText(getApplicationContext(), "触发本地刷新积分1："+credits,Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onLoginClick(WebView webView, String s) {
                        Toast.makeText(MainActivity.this, s, Toast.LENGTH_SHORT).show();
                    }
                })
                .build();

        DmMall.getInstance(this)
                .with(config)//自定义商城配置，可选
                .enterMall(new DmMallEnterListener() {//打开/进入商城，传入监听，监听进入商城过程
                    @Override
                    public void entering() {
                        Log.e(TAG,"----->正在进入积分商城");
                    }

                    @Override
                    public void fail(String msg) {
                            Log.e(TAG,"----->"+msg);
                        Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void enterOk() {
                        Log.e(TAG,"----->进入成功");
                    }
                });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        //调用权限申请帮助类的相关方法
        mPermissionHelper.onRequestPermissionsResult(requestCode,permissions,grantResults);
    }
}
